const researchBtn = document.getElementById("researchBtn");
const companyInput = document.getElementById("companyInput");
const chatBox = document.getElementById("chatBox");
const progressFill = document.getElementById("progressFill");
const progressText = document.getElementById("progressText");
const companyInfoList = document.getElementById("companyInfoList");
const productsEl = document.getElementById("products");
const painpointsEl = document.getElementById("painpoints");
const competitorsEl = document.getElementById("competitors");
const downloadBtn = document.getElementById("downloadBtn");

if (downloadBtn) {
    downloadBtn.addEventListener("click", () => {
        window.location.href = "/download-pdf";
    });
}

researchBtn.addEventListener("click", async () => {

    const company = companyInput.value.trim();

    if(company === ""){
        alert("Please enter a company name or website.");
        return;
    }

    addUserMessage(company);

    companyInput.value = "";

    await startProgress();

    try {
        const model = localStorage.getItem("research_settings")
            ? JSON.parse(localStorage.getItem("research_settings")).model
            : "openai/gpt-4.1-mini";

        const response = await fetch("http://127.0.0.1:5000/research", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                company: company,
                model: model
            })
        });

        const data = await response.json();

        const pages = data.content || {};
        const firstPageKey = Object.keys(pages)[0];
        const firstPage = pages[firstPageKey] || {};
        const details = firstPage.details || {};

        if (companyInfoList) {
            companyInfoList.innerHTML = `
                <li><strong>Name :</strong> ${details.title || data.company || "-"}</li>
                <li><strong>Website :</strong> ${data.website || "-"}</li>
                <li><strong>Phone :</strong> ${(details.phones || []).join(", ") || "-"}</li>
                <li><strong>Email :</strong> ${(details.emails || []).join(", ") || "-"}</li>
                <li><strong>Address :</strong> ${details.address || "-"}</li>
            `;
        }

        if (productsEl) {
            productsEl.innerHTML = "No products extracted yet.";
        }

        if (painpointsEl) {
            painpointsEl.innerHTML = "No pain points extracted yet.";
        }

        if (competitorsEl) {
            competitorsEl.innerHTML = "No competitors extracted yet.";
        }

        let msg = `✅ Official Website Found\n\n${data.website}\n\nPages Crawled:\n`;

        for (const page of Object.keys(data.content || {})) {
            msg += `• ${page}\n`;
        }

        addAIMessage(msg);

        const downloadBtn = document.getElementById("downloadBtn");
        if (downloadBtn) {
            downloadBtn.style.display = "block";
        }
    } catch (error) {
        console.error(error);
        addAIMessage("❌ Failed to connect to the backend.");
    }

});

function addUserMessage(text){

    chatBox.innerHTML += `
    <div class="message user">
        <div class="avatar">
            <i class="fa-solid fa-user"></i>
        </div>

        <div class="bubble">
            ${text}
        </div>
    </div>
    `;

    scrollBottom();

}

function addAIMessage(text){

    chatBox.innerHTML += `
    <div class="message ai">
        <div class="avatar">
            <i class="fa-solid fa-robot"></i>
        </div>

        <div class="bubble">
            ${text.replace(/\n/g,"<br>")}
        </div>
    </div>
    `;

    scrollBottom();

}

async function startProgress(){

    const steps=[
        ["Searching Official Website...",20],
        ["Crawling Website...",45],
        ["Collecting Public Information...",65],
        ["Generating AI Insights...",85],
        ["Preparing Report...",100]
    ];

    for(const step of steps){

        progressText.innerText=step[0];

        progressFill.style.width=step[1]+"%";

        await sleep(900);

    }

}

function sleep(ms){

    return new Promise(resolve=>setTimeout(resolve,ms));

}

function scrollBottom(){

    chatBox.scrollTop=chatBox.scrollHeight;

}