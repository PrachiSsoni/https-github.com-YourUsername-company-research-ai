import re
from bs4 import BeautifulSoup

PHONE_REGEX = r'(\+?\d[\d\s\-\(\)]{8,}\d)'
EMAIL_REGEX = r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'


def extract_company_details(html, url):

    soup = BeautifulSoup(html, "html.parser")

    text = soup.get_text(" ", strip=True)

    phones = list(set(re.findall(PHONE_REGEX, text)))

    emails = list(set(re.findall(EMAIL_REGEX, text)))

    title = ""

    if soup.title:
        title = soup.title.text.strip()

    logo = ""

    logo_tag = soup.find("img")

    if logo_tag and logo_tag.get("src"):
        logo = logo_tag["src"]

    social_links = []

    for a in soup.find_all("a", href=True):

        href = a["href"]

        if any(site in href for site in [
            "linkedin",
            "facebook",
            "twitter",
            "instagram",
            "youtube"
        ]):
            social_links.append(href)

    return {

        "title": title,

        "phones": phones,

        "emails": emails,

        "logo": logo,

        "social_links": list(set(social_links))

    }