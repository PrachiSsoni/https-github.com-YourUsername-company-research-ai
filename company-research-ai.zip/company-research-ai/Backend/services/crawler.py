import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
from services.extractor import extract_company_details

MAX_PAGES = 10

IGNORE_WORDS = [
    "login",
    "signup",
    "register",
    "privacy",
    "terms",
    "cart",
    "checkout",
    "account",
    "admin"
]


def clean_text(soup):

    for tag in soup([
        "script",
        "style",
        "noscript",
        "svg",
        "img",
        "iframe"
    ]):
        tag.decompose()

    return soup.get_text(
        separator=" ",
        strip=True
    )


def crawl_website(base_url):

    headers = {
        "User-Agent": "Mozilla/5.0"
    }

    visited = set()

    queue = [base_url]

    pages = {}

    domain = urlparse(base_url).netloc

    while queue and len(visited) < MAX_PAGES:

        url = queue.pop(0)

        if url in visited:
            continue

        visited.add(url)

        try:

            response = requests.get(
                url,
                headers=headers,
                timeout=10
            )

            if response.status_code != 200:
                continue

            soup = BeautifulSoup(
                response.text,
                "html.parser"
            )

            text = clean_text(soup)
            details = extract_company_details(response.text, url)

            pages[url] = {
                "text": text[:8000],
                "details": details
            }

            links = soup.find_all("a")

            for link in links:

                href = link.get("href")

                if not href:
                    continue

                full = urljoin(url, href)

                parsed = urlparse(full)

                if parsed.netloc != domain:
                    continue

                if any(word in full.lower() for word in IGNORE_WORDS):
                    continue

                if full not in visited and full not in queue:
                    queue.append(full)

        except Exception as e:

            print(e)

    return pages