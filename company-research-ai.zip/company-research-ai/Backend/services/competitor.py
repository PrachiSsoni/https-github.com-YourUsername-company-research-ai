import requests
from dotenv import load_dotenv
import os

load_dotenv()

SERPER_API_KEY = os.getenv("SERPER_API_KEY")

SERPER_URL = "https://google.serper.dev/search"


def find_competitors(company_name):
    """
    Search competitors using Serper.dev
    """

    headers = {
        "X-API-KEY": SERPER_API_KEY,
        "Content-Type": "application/json"
    }

    payload = {
        "q": f"{company_name} competitors"
    }

    try:
        response = requests.post(
            SERPER_URL,
            headers=headers,
            json=payload,
            timeout=15
        )

        if response.status_code != 200:
            return []

        data = response.json()

        competitors = []

        for item in data.get("organic", [])[:5]:

            competitors.append({
                "name": item.get("title", "Unknown"),
                "website": item.get("link", "")
            })

        return competitors

    except Exception as e:

        print("Competitor Error:", e)

        return []