import os
import json
import requests
from dotenv import load_dotenv

load_dotenv()

OPENROUTER_API_KEY = os.getenv("OPENROUTER_API_KEY")
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"


def analyze_company(company_name, website, website_content, model="openai/gpt-4.1-mini"):
    """Analyze company information using OpenRouter AI and return structured JSON."""

    if not OPENROUTER_API_KEY:
        return {
            "summary": "OpenRouter API key is not configured.",
            "products": [],
            "pain_points": [],
            "industry": "",
            "country": "",
            "competitors": []
        }

    prompt = f"""
You are an expert business analyst.

Analyze this company.

Company Name:
{company_name}

Website:
{website}

Website Content:
{website_content[:12000]}

Return ONLY valid JSON.

{{
  "summary":"",
  "products":[],
  "pain_points":[],
  "industry":"",
  "country":"",
  "competitors":[]
}}
"""

    headers = {
        "Authorization": f"Bearer {OPENROUTER_API_KEY}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": model,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3
    }

    try:
        response = requests.post(
            OPENROUTER_URL,
            headers=headers,
            json=payload,
            timeout=60
        )
        response.raise_for_status()
        data = response.json()
        text = data["choices"][0]["message"]["content"]

        try:
            parsed = json.loads(text)
            return {
                "summary": parsed.get("summary", ""),
                "products": parsed.get("products", []),
                "pain_points": parsed.get("pain_points", []),
                "industry": parsed.get("industry", ""),
                "country": parsed.get("country", ""),
                "competitors": parsed.get("competitors", [])
            }
        except Exception:
            return {
                "summary": text,
                "products": [],
                "pain_points": [],
                "industry": "",
                "country": "",
                "competitors": []
            }
    except Exception as exc:
        return {
            "summary": f"AI analysis failed: {exc}",
            "products": [],
            "pain_points": [],
            "industry": "",
            "country": "",
            "competitors": []
        }