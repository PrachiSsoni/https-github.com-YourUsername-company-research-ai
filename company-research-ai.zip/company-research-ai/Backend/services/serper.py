import os
import requests
from dotenv import load_dotenv

load_dotenv()

SERPER_API_KEY = os.getenv("SERPER_API_KEY")

SERPER_URL = "https://google.serper.dev/search"


def get_official_website(query):

    headers = {
        "X-API-KEY": SERPER_API_KEY,
        "Content-Type": "application/json"
    }

    payload = {
        "q": query
    }

    response = requests.post(
        SERPER_URL,
        headers=headers,
        json=payload
    )

    if response.status_code != 200:
        return None

    data = response.json()

    organic = data.get("organic", [])

    if not organic:
        return None

    return organic[0]["link"]