import requests


def send_to_discord(bot_token, channel_id, message, pdf_path=None):

    url = f"https://discord.com/api/v10/channels/{channel_id}/messages"

    headers = {
        "Authorization": f"Bot {bot_token}"
    }

    payload = {
        "content": message
    }

    response = requests.post(
        url,
        headers=headers,
        json=payload
    )

    return response.status_code