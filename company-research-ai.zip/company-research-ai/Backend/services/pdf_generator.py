from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph

def generate_pdf(report_data, filename="company_report.pdf"):

    doc = SimpleDocTemplate(filename)

    styles = getSampleStyleSheet()

    story = []

    story.append(Paragraph("<b>AI Company Research Report</b>", styles["Title"]))

    story.append(Paragraph("<br/>", styles["Normal"]))

    story.append(
        Paragraph(
            f"<b>Company Name:</b> {report_data.get('company','')}",
            styles["Normal"]
        )
    )

    story.append(
        Paragraph(
            f"<b>Website:</b> {report_data.get('website','')}",
            styles["Normal"]
        )
    )

    story.append(
        Paragraph(
            f"<b>Phone:</b> {report_data.get('phone','N/A')}",
            styles["Normal"]
        )
    )

    story.append(
        Paragraph(
            f"<b>Address:</b> {report_data.get('address','N/A')}",
            styles["Normal"]
        )
    )

    story.append(Paragraph("<br/>", styles["Normal"]))

    story.append(
        Paragraph("<b>Products / Services</b>", styles["Heading2"])
    )

    for product in report_data.get("products", []):

        story.append(
            Paragraph(f"• {product}", styles["Normal"])
        )

    story.append(Paragraph("<br/>", styles["Normal"]))

    story.append(
        Paragraph("<b>AI Pain Points</b>", styles["Heading2"])
    )

    for point in report_data.get("pain_points", []):

        story.append(
            Paragraph(f"• {point}", styles["Normal"])
        )

    story.append(Paragraph("<br/>", styles["Normal"]))

    story.append(
        Paragraph("<b>Competitors</b>", styles["Heading2"])
    )

    for competitor in report_data.get("competitors", []):

        story.append(
            Paragraph(
                f"• {competitor['name']} - {competitor['website']}",
                styles["Normal"]
            )
        )

    doc.build(story)

    return filename