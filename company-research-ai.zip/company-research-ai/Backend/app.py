import os
import json
from flask import Flask, render_template, request, jsonify, send_file

from services.serper import get_official_website
from services.crawler import crawl_website
from services.extractor import extract_company_details
from services.openrouter import analyze_company
from services.competitor import find_competitors
from services.pdf_generator import generate_pdf
from services.discord_bot import send_to_discord
from services.pdf_generator import generate_pdf

app = Flask(__name__)

BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TEMPLATE_DIR = os.path.join(BASE_DIR, "frontend", "template")
STATIC_DIR = os.path.join(BASE_DIR, "frontend", "static")

app = Flask(__name__, template_folder=TEMPLATE_DIR, static_folder=STATIC_DIR)

# Store latest report temporarily
latest_report = {}


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/settings")
def settings():
    return render_template("settings.html")


@app.route("/research", methods=["POST"])
def research():

    data = request.get_json(silent=True) or {}

    company = data.get("company", "")
    model = data.get("model", "openai/gpt-4.1-mini")

    if not isinstance(company, str):
        company = ""

    company = company.strip()

    if not company:
        return jsonify({
            "company": company,
            "website": None,
            "pages": [],
            "content": {},
            "message": "Please provide a company name or URL."
        }), 400

    if company.startswith("http://") or company.startswith("https://"):
        website = company
    else:
        website = get_official_website(company)

    if not website:
        return jsonify({
            "company": company,
            "website": None,
            "pages": [],
            "content": {},
            "message": "No website found for the provided company."
        })

    print("=" * 50)
    print(website)
    print("=" * 50)

    pages = crawl_website(website)

    print(pages)

    first_page = next(iter(pages.values()), {})
    details = first_page.get("details", {}) if isinstance(first_page, dict) else {}

    phone = ""
    address = ""

    if isinstance(details, dict):
        phones = details.get("phones", [])
        if isinstance(phones, list) and phones:
            phone = phones[0]

    ai = analyze_company(
        company_name=company,
        website=website,
        website_content=str(pages),
        model=model
    )

    competitors = find_competitors(company)

    report_data = {
        "company": company,
        "website": website,
        "phone": phone,
        "address": address,
        "products": ai.get("products", []),
        "pain_points": ai.get("pain_points", []),
        "competitors": competitors
    }

    pdf_file = generate_pdf(report_data)

    settings = data.get("settings", {})

    bot_token = settings.get("botToken", "")
    channel_id = settings.get("channelId", "")
    applicant_name = settings.get("applicantName", "")
    applicant_email = settings.get("applicantEmail", "")

    if bot_token and channel_id:
        message = f"""
Applicant Name: {applicant_name}

Applicant Email: {applicant_email}

Company: {company}

Website: {website}
"""

        send_to_discord(
            bot_token,
            channel_id,
            message
        )

    report = {
        "company": company,
        "website": website,
        "pages": list(pages.keys()),
        "content": pages,
        "summary": ai.get("summary", ""),
        "products": ai.get("products", []),
        "pain_points": ai.get("pain_points", []),
        "competitors": competitors,
        "pdf_file": pdf_file
    }

    latest_report.clear()
    latest_report.update(report)

    return jsonify(report)


@app.route("/download-pdf", methods=["GET"])
def download_pdf():
    if not latest_report:
        return jsonify({"error": "No report available yet."}), 400

    pdf_path = latest_report.get("pdf_file")

    if not pdf_path or not os.path.exists(pdf_path):
        return jsonify({"error": "PDF not found."}), 404

    return send_file(pdf_path, as_attachment=True, download_name="company_report.pdf")


if __name__ == "__main__":
    app.run(debug=True)